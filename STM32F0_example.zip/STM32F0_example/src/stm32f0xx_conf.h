#define assert_param(expr) ((void)0)
